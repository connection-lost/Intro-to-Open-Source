double mysqrt(double x);

