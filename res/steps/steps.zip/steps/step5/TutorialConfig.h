#define USE_MYMATH
// the configured options and settings for Tutorial
#define Tutorial_VERSION_MAJOR 1
#define Tutorial_VERSION_MINOR 0

// does the platform provide exp and log functions?
/* #undef HAVE_LOG */
/* #undef HAVE_EXP */
